import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateaccountComponent } from './view/createaccount.component';
import { ListacountComponent } from './view/listacount.component';
import { HomeComponent } from './view/home.component';
import { PagenotfoundComponent } from './view/pagenotfound.component';
import { AccountdetailComponent } from './view/accountdetail.component';
import { AccountinfoComponent } from './view/accountinfo.component';
import { AccountcontactComponent } from './view/accountcontact.component';
import { LocationStrategy, PathLocationStrategy, HashLocationStrategy } from '@angular/common';
import { SearchComponent } from './view/search.component';
import { AaComponent } from './mycomp/aa/aa.component';



@NgModule({
  declarations: [
    AppComponent,
    CreateaccountComponent,
    ListacountComponent,
    HomeComponent,
    PagenotfoundComponent,
    AccountdetailComponent,
    AccountinfoComponent,
    AccountcontactComponent,
    SearchComponent,
    AaComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [
    {provide:LocationStrategy,useClass:PathLocationStrategy}
 //  {provide:LocationStrategy,useClass:HashLocationStrategy}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
