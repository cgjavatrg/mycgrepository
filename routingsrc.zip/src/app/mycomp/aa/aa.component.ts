import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aa',
  templateUrl: './aa.component.html',
  styleUrls: ['./aa.component.css']
})
export class AaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
