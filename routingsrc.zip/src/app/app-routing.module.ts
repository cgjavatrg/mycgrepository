import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateaccountComponent } from './view/createaccount.component';
import { ListacountComponent } from './view/listacount.component';
import { HomeComponent } from './view/home.component';
import { PagenotfoundComponent } from './view/pagenotfound.component';
import { AccountdetailComponent } from './view/accountdetail.component';
import { AccountinfoComponent } from './view/accountinfo.component';
import { AccountcontactComponent } from './view/accountcontact.component';
import { SearchComponent } from './view/search.component';


const routes: Routes = [
  {path:'create',component:CreateaccountComponent},
  {path:'list',component:ListacountComponent},
  {
    path:'list/:id', component:AccountdetailComponent,
    //this children will be seend in AccountdetailComponent
    // template as router-outlet , they are relative path
    children:[
      {path:'info',component:AccountinfoComponent},
      {path:'contact',component:AccountcontactComponent}
    ]
  },

  {path:'home',component:HomeComponent},
  {path:'search',component:SearchComponent},
  {path:'',redirectTo:'home',pathMatch:'full'},
  {path:'**',component:PagenotfoundComponent}  // wildcard route
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  // exports is used to make the RouterModule available and
  // accessible to the app root module
  exports: [RouterModule]
})
export class AppRoutingModule { }
