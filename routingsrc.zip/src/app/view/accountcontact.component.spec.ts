import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountcontactComponent } from './accountcontact.component';

describe('AccountcontactComponent', () => {
  let component: AccountcontactComponent;
  let fixture: ComponentFixture<AccountcontactComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountcontactComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountcontactComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
