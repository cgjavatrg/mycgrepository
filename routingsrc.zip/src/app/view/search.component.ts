import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  // query params work as optional parameters
  // only client can see it
  // these parameters are part of 
  // url which comes as http get method
  // but no need to modify route configuration
  
  mydata:any;
  constructor(private route:ActivatedRoute) {
    this.route.queryParams.subscribe((data)=>{
      this.mydata=data;
    }
    );
   }

  ngOnInit(): void {
  }

}
