import { Component, OnInit } from '@angular/core';
import {ActivatedRoute,Router, ParamMap} from '@angular/router';
@Component({
  selector: 'app-accountdetail',
  template: `
    <h1>
      This is account with id {{myacno}}
    </h1>
    <p>
    <button (click)="getaccountinfo()">Account Info</button>
    <button (click)="getaccountcontact()">Account Contact</button>
    </p>
    <hr>
    <router-outlet></router-outlet>
    <hr>
    <p>
      <button (click)="goPrevious()">Previous << </button>
      <button (click)="goNext()">Next >> </button>
    </p>
    <p>
    <button (click)="goToAccounts()">Back to List</button>
    </p>
  `,
  styles: [
  ]
})
export class AccountdetailComponent implements OnInit {
  myacno:number;
  constructor(private route:ActivatedRoute,private router:Router) { }

  ngOnInit(): void {
   // this.myacno=parseInt(this.route.snapshot.paramMap.get('id'));
    this.route.paramMap.subscribe((param:ParamMap)=>{
      this.myacno=parseInt(param.get('id'));
    }
   );
  }

  goPrevious(){
    let previousacno=this.myacno>100?this.myacno-1:100;
    this.router.navigate(['list',previousacno]);
  }

  goNext(){
    let nextacno=this.myacno<104?this.myacno+1:104;
    
    this.router.navigate(['list',nextacno]);
  }
  goToAccounts() {
    this.router.navigate(['list']);
  }

  getaccountinfo(){
    this.router.navigate(['info'],{relativeTo:this.route});
  }
  getaccountcontact() {
    this.router.navigate(['contact'],{relativeTo:this.route});
  }
}
