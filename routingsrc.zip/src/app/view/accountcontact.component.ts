import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accountcontact',
  template: `
    <p>
      accountcontact works!
    </p>
  `,
  styles: [
  ]
})
export class AccountcontactComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
