import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
@Component({
  selector: 'app-listacount',
  templateUrl: './listacount.component.html',
  styleUrls: ['./listacount.component.css']
})
export class ListacountComponent implements OnInit {
  accounts:any[]=[
  {'acno':100,'holder':'Ram'},
  {'acno':101,'holder':'Sham'},
  {'acno':102,'holder':'Krishna'},
  {'acno':103,'holder':'Ramesh'},
  {'acno':104,'holder':'Ganesh'}
];
  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  onSelect(account) {
   // alert(account.acno);
    this.router.navigate(['list',account.acno]);
  }
}
