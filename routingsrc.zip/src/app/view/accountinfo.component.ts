import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accountinfo',
  template: `
    <p>
      accountinfo works!
    </p>
  `,
  styles: [
  ]
})
export class AccountinfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
