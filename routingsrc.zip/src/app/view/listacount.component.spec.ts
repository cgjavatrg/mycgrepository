import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListacountComponent } from './listacount.component';

describe('ListacountComponent', () => {
  let component: ListacountComponent;
  let fixture: ComponentFixture<ListacountComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListacountComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListacountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
