export class Account {
    aid:number;
    customer:String;
    balance:number;
    email:String;
}
