import { Component, OnInit } from '@angular/core';
import { UserDTO } from '../user-dto';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user:UserDTO;
  username:string;
  password:string;
  loginerror:string=null;
  constructor(private service:UserService) { }

  ngOnInit(): void {
  }

  myLogin():void {
    this.service.loginfun(this.username,this.password).subscribe(
      (data)=>this.user=data,
      (error)=>this.loginerror=error,
      ()=>{
        this.loginerror=null;
        console.log('Login completed');
      }
         
    )
  }

}
