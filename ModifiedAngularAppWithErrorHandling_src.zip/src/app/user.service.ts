import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { User } from './user';
import { UserDTO } from './user-dto';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private baseUrl:string = 'http://localhost:8082/';  


  
  constructor(private http:HttpClient) { }  

  loginfun(username:string,password:string):Observable<UserDTO> {
    let params = new HttpParams()
    .set('username', username)
    .set('password', password)
    let url:string=`${this.baseUrl}accounts/login`;
     return this.http.post<UserDTO>(url,params   ).
     pipe(catchError(this.handleError));
  }

  createUser(regUser:User):Observable<UserDTO> {
    let url:string=`${this.baseUrl}accounts/createUser`;
    return this.http.post<UserDTO>(url,regUser).
     pipe(catchError(this.handleError));
  }

  private handleError(error: HttpErrorResponse){
    let errorMsg:string='';
    if(error.error instanceof ErrorEvent){
        console.error('Client Side Error: ' , error.error.message);
        errorMsg=error.error.message;
       
    }else{
      console.error('Server Side Error: ', error);
      errorMsg=error.error;
     
    }

    
    return throwError(errorMsg);
      
  }

  
}
