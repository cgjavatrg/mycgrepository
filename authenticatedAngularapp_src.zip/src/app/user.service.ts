import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { User } from './user';
import { UserDTO } from './user-dto';
import { retry, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private baseUrl:string = 'http://localhost:8082/';  

  private isloggedIn: boolean;
  private activeUser: UserDTO=null;
  
  constructor(private http:HttpClient) {
    this.isloggedIn = false;
  }  

  setIsLoggedIn (isloggedIn:boolean):void{
    this.isloggedIn=isloggedIn;
  }

  getIsLoggedIn():boolean {
    return this.isloggedIn;
  }

  setUserDTO(userdto:UserDTO) {
    this.activeUser=userdto;
  }

  getActiveUser():UserDTO {
    return this.activeUser;
  }

  logout() {
    this.isloggedIn=false;
    this.activeUser=null;
  }

  loginfun(username:string,password:string):Observable<UserDTO> {
    let params = new HttpParams()
    .set('username', username)
    .set('password', password)
    let url:string=`${this.baseUrl}accounts/login`;
     return this.http.post<UserDTO>(url,params   ).
     pipe(catchError(this.handleError));
  }

  createUser(regUser:User):Observable<User> {
    let url:string=`${this.baseUrl}accounts/createUser`;
    return this.http.post<User>(url,regUser).
     pipe(catchError(this.handleError));
  }

  getAllUser():Observable<User[]> {
    let url:string=`${this.baseUrl}accounts/users`;
    return this.http.get<User[]>(url).
    pipe(catchError(this.handleError));
  }

  private handleError(error: HttpErrorResponse){
    let errorMsg:string='';
    if(error.error instanceof ErrorEvent){
        console.error('Client Side Error: ' , error.error.message);
        errorMsg=error.error.message;
       
    }else{
      console.error('Server Side Error: ', error);
      errorMsg=error.error;
     
    }

    
    return throwError("Error Message =>"+errorMsg);
      
  }

  
}
