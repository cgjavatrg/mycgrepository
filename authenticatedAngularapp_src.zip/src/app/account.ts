import { User } from "./user";

export class Account {
    aid:number;
    customer:String;
    balance:number;
    email:String;
    user:User;
}
