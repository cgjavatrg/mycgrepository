import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Comp1Component } from './comp1/comp1.component';
import { LifeCycleHookComponent } from './life-cycle-hook/life-cycle-hook.component';

const routes: Routes = [
  {path:"comp1",component:Comp1Component},
  {path:"lifecycle",component:LifeCycleHookComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
