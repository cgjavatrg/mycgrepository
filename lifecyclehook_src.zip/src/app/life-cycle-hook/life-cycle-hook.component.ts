import { AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, DoCheck, OnChanges, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-life-cycle-hook',
  templateUrl: './life-cycle-hook.component.html',
  styleUrls: ['./life-cycle-hook.component.css']
})
export class LifeCycleHookComponent  implements OnChanges, OnInit, 
DoCheck, AfterContentInit, AfterContentChecked, AfterViewInit,
AfterViewChecked, OnDestroy {
    msg:string="";
  ngOnChanges(changes: import("@angular/core").SimpleChanges): void {
    //alert("1. on changes called");
    this.msg+= "1. on changes called <br>\n";
  }
  ngOnInit(): void {
    //alert("2. on init is called");
    this.msg+= "2. on init is called <br>";
  }
  ngDoCheck(): void {
    //("3. do check is called");
    this.msg+= "3. do check is called <br>";
  }
  ngAfterContentInit(): void {
    //alert("4. after content init called");
    this.msg+= "4. after content init called <br>";
  }
  ngAfterContentChecked(): void {
   // alert("5. after content check called");
   this.msg+= "5. after content check called <br>";
  }
  ngAfterViewInit(): void {
   // alert('6. after view init called');
   this.msg+= "6. after view init called <br>";
  }
 
  ngAfterViewChecked(): void {
    //alert('7. after view init checked');
    this.msg+= "7. after view checked called <br>";
  }

  ngOnDestroy(): void {
  //  alert('8. on destroy called');
  this.msg+= "8. on destroy called <br>";
  }
  title = 'ngcanvas';

  constructor(private router:Router){
   // alert("Constructor ");
   this.msg+= "0. constructor <br>";
  }

  change() {
    this.title="Manjiri";
  }
  go() {
    this.router.navigate(["comp1"]);
  }
}
