import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MydirectivecompComponent } from './mydirectivecomp.component';

describe('MydirectivecompComponent', () => {
  let component: MydirectivecompComponent;
  let fixture: ComponentFixture<MydirectivecompComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MydirectivecompComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MydirectivecompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
