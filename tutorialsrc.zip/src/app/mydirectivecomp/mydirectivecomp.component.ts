import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mydirectivecomp',
  templateUrl: './mydirectivecomp.component.html',
  styleUrls: ['./mydirectivecomp.component.css']
})
export class MydirectivecompComponent implements OnInit {
  showAd:boolean=false;
  a:number=34;
  b:number=22;
  mycolor:string;

  myclass={
    'one':false,
    'five':true,
    'three':true
  };

  students : Student[] = [
    {
        ID: 'std101', FirstName: 'Preety', LastName: 'Tiwary',
        Branch: 'CSE', DOB: '29/02/1988', Gender: 'Female'
    },
    {
        ID: 'std102', FirstName: 'Anurag', LastName: 'Mohanty', 
        Branch: 'ETC', DOB: '23/05/1989', Gender: 'Male'
    },
    {
        ID: 'std103', FirstName: 'Priyanka', LastName: 'Dewangan', 
        Branch: 'CSE', DOB: '24/07/1992', Gender: 'Female'
    },
    {
        ID: 'std104', FirstName: 'Hina', LastName: 'Sharma', 
        Branch: 'ETC', DOB: '19/08/1990', Gender: 'Female'
    },
    {
        ID: 'std105', FirstName: 'Sambit', LastName: 'Satapathy', 
        Branch: 'CSE', DOB: '12/94/1991', Gender: 'Male'
    }
  ];

  cities = ['Miami', 'Sao Paulo', 'New York'];

  condition:boolean=false;
  constructor() { }

  ngOnInit() {
  }

  myfun():boolean {
    let res=Math.round(Math.random()*100);
    if(res>50)
    {
      return true;
    }
      else
      {
      return false;
      }
  }
}

class Student {
  ID:string;
  FirstName:string;
  LastName:string;
  Branch:string;
  DOB:string;
  Gender:string;
}
