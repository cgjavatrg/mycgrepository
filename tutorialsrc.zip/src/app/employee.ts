export class Employee {
    empId:number=0;
    empName:string='';
    empSal:number=0;
    empDep:string='';
    empjoiningdate:string='';
}
