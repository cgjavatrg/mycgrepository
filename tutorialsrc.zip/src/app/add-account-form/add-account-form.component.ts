import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Account } from '../account';
import { AccountService } from '../account.service';

@Component({
  selector: 'app-add-account-form',
  templateUrl: './add-account-form.component.html',
  styleUrls: ['./add-account-form.component.css']
})
export class AddAccountFormComponent implements OnInit {
  account:Account=new Account();
  constructor(private router:Router,private service:AccountService) { }

  ngOnInit() {
  }

  insertAccount(){
    //alert(JSON.stringify(this.account));
    this.service.createAccount(this.account).subscribe(
      data=>this.account=data
    );
    this.router.navigate(['tutorial/listacc']);
  }
}
