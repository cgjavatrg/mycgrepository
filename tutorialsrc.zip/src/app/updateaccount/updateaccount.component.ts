import { AfterViewInit, Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Account } from '../account';
import { AccountService } from '../account.service';

@Component({
  selector: 'app-updateaccount',
  templateUrl: './updateaccount.component.html',
  styleUrls: ['./updateaccount.component.css']
})
export class UpdateaccountComponent implements OnInit,AfterViewInit {
  account:Account;
  myaid:number;
  constructor(private route:ActivatedRoute , private router:Router, 
    private service:AccountService) { }
  ngAfterViewInit(): void {
    throw new Error('Method not implemented.');
  }


    accountsaveform=new FormGroup({
      aid:new FormControl('',[Validators.required , Validators.minLength(3) ])  ,
      customer:new FormControl('' , [Validators.required , Validators.minLength(5) ] ),  
      balance:new FormControl('',[Validators.required,Validators.min(2000)]),  
      email:new FormControl('',[Validators.required,Validators.email])  
    });  
  
  ngOnInit() {
    this.account=new Account();

    this.myaid=this.route.snapshot.params['id'];
    //alert(this.myaid);
    this.service.getAccount(this.myaid).subscribe(
      data=>this.account=data
      );

      this.Aid.setValue(this.account.aid);
      this.Customer.setValue(this.account.customer);
      this.Balance.setValue(this.account.balance);
      this.Email.setValue(this.account.email);

  }

  get Aid(){  
    return this.accountsaveform.get('aid');  
  }  
  
  get Customer(){  
    return this.accountsaveform.get('customer');  
  }  

  
  get Balance(){  
    return this.accountsaveform.get('balance');  
  }  
  
  get Email(){  
    return this.accountsaveform.get('email');  
  }  
  updateAccount():void{
    this.account.aid = this.Aid.value;
    this.account.customer = this.Customer.value;
    this.account.balance = this.Balance.value;
    this.account.email=this.Email.value;

    this.service.updateAccount(this.account.aid,this.account).subscribe(
      data=>this.account=data
    );

    this.router.navigate(['tutorial/listacc']);
  }

}
