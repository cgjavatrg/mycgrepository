import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Account } from '../account';
import { AccountService } from '../account.service';

@Component({
  selector: 'app-listaccount',
  templateUrl: './listaccount.component.html',
  styleUrls: ['./listaccount.component.css']
})
export class ListaccountComponent implements OnInit {
  accounts: Observable<Account[]>;

  constructor(private accountservice:AccountService, private router:Router) { }

  ngOnInit(): void {
    this.reloadData();
  }

  reloadData() {
    this.accounts = this.accountservice.getAccountsList();
  }

  addForm():void{
    this.router.navigate(['tutorial/addAccount']);
  }
  goForUpdate(aid:number):void {
    //alert(aid);
    this.router.navigate(['tutorial/updateaccount',aid]);
  }
}
