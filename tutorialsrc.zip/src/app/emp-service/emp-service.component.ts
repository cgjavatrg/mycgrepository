import { Component, OnInit } from '@angular/core';
import { EmpService } from '../emp.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-emp-service',
  templateUrl: './emp-service.component.html',
  styleUrls: ['./emp-service.component.css']
})
export class EmpServiceComponent implements OnInit {

  employees:Employee[]=[];
  postemp:Employee = {
    "empId": 5,
    "empName": "Manjiri",
    "empSal": 58000,
    "empDep": "LnD",
    "empjoiningdate":"12/2/2023"
};

  constructor(private empService:EmpService) { }

  ngOnInit(): void {
    this.getAllEmp();
  }
  getAllEmp(){
    this.empService.getEmpListByHttp().subscribe((empdata)=>{
      this.employees=empdata;
      console.log(empdata);
    } )
  }

  postempfun() {
    this.empService.postEmp(this.postemp).subscribe(
      (response)=> {console.log(response),
      error=>console.log(error)});
  }

  updateFun(){
    this.postemp.empSal=88000;
    this.empService.putEmp(this.postemp,5).subscribe(
      (response)=> {console.log(response),
      error=>console.log(error)});
  }
  deleteEmp(id:number){
    this.empService.delEmp(id).subscribe(
      (response)=> {console.log(response),
      error=>console.log(error)});
  }


}
