import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccountserviceComponent } from './accountservice/accountservice.component';
import { AddAccountFormComponent } from './add-account-form/add-account-form.component';
import { AppComponent } from './app.component';
import { Comp1Component } from './datab/comp1/comp1.component';
import { EmpServiceComponent } from './emp-service/emp-service.component';
import { ListaccountComponent } from './listaccount/listaccount.component';
import { MydirectivecompComponent } from './mydirectivecomp/mydirectivecomp.component';
import { MypipeComponent } from './mypipe/mypipe.component';
import { UpdateaccountComponent } from './updateaccount/updateaccount.component';
import { UrlserviceComponent } from './urlservice/urlservice.component';


const routes: Routes = [
 { path:"tutorial/databind",component:Comp1Component},
 {path:"tutorial/pipe",component:MypipeComponent},
 {path:"tutorial/directive",component:MydirectivecompComponent},
 {path:"tutorial/empservice",component:EmpServiceComponent},
 {path:"tutorial/urlservice",component:UrlserviceComponent},
 { path:"tutorial/accountservice",component:AccountserviceComponent},
  { path:"tutorial/listacc",component:ListaccountComponent},
  {path:"tutorial/addAccount",component:AddAccountFormComponent},
  { path:"tutorial/updateaccount/:id",component:UpdateaccountComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
