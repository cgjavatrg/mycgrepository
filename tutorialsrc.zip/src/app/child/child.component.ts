import { Component, OnInit, Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
  @Output() branchevent:EventEmitter<string>=new EventEmitter<string>(); // emit string data to parent
  constructor() { }

  ngOnInit() {
  }

  senddata(val:string) {
    console.log("Value is "+val);
    this.branchevent.emit(val);
  }
}
