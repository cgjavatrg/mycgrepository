import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Comp1Component } from './datab/comp1/comp1.component';
import { MypipeComponent } from './mypipe/mypipe.component';
import { HomeComponent } from './home/home.component';
import { ChildComponent } from './child/child.component';
import { MydirectivecompComponent } from './mydirectivecomp/mydirectivecomp.component';
import { UnlessDirective } from './unless.directive';
import { CardHoverDirective } from './card-hover.directive';
import { ExponentialStrengthPipe } from './exponential-strength.pipe';
import { FilterPipe } from './filter.pipe';
import { EmpServiceComponent } from './emp-service/emp-service.component';
import { UrlserviceComponent } from './urlservice/urlservice.component';
import { TemplateDrivenComponent } from './template-driven/template-driven.component';
import { EmpService } from './emp.service';
import { UrlService } from './url.service';
import { AccountserviceComponent } from './accountservice/accountservice.component';
import { ListaccountComponent } from './listaccount/listaccount.component';
import { AddAccountFormComponent } from './add-account-form/add-account-form.component';
import { UpdateaccountComponent } from './updateaccount/updateaccount.component';

@NgModule({
  declarations: [
    AppComponent,
    Comp1Component,
    MypipeComponent,
    HomeComponent,
    ChildComponent,
    MydirectivecompComponent,
    UnlessDirective,
    CardHoverDirective,
    ExponentialStrengthPipe,
    FilterPipe,
    EmpServiceComponent,
    UrlserviceComponent,
    TemplateDrivenComponent,
    AccountserviceComponent,
    ListaccountComponent,
    AddAccountFormComponent,
    UpdateaccountComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [EmpService,UrlService],
  bootstrap: [AppComponent]
})
export class AppModule { }
