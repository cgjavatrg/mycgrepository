import { Component, OnInit } from '@angular/core';
import { Account } from '../account';
import { AccountService } from '../account.service';

@Component({
  selector: 'app-accountservice',
  templateUrl: './accountservice.component.html',
  styleUrls: ['./accountservice.component.css']
})
export class AccountserviceComponent implements OnInit {

  accountdata:Account[]= [];

  addacc:Account={
    aid:500,
    customer:"MAnjiri",
    balance:40000,
    email:"manjiri@tseedu.com"
  }
  constructor(private service:AccountService) { }

  ngOnInit() {
   this.getDataFun();
  }
  getDataFun(){
    this.service.getAccountsList().subscribe((data) => {
      this.accountdata = data;
      console.log(JSON.stringify (this.accountdata));
   });
  }
  postData() {
    this.service.createAccount(this.addacc) .subscribe(
      data => console.log(data),
     error => console.log(error));
  }
  updateData(){
    this.addacc.balance=88000;
    this.service.updateAccount(500,this.addacc).subscribe(
      data => console.log(data),
     error => console.log(error));;
  }
  deleteData(id:number){
    this.service.deleteAccount(id).subscribe(
      data => console.log(data),
     error => console.log(error));;
  }
}

