import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {
/*
  transform(value: any, ...args: any[]): any {
    return null;
  }
  */
  transform(name:string, salary:number): any {
    if(salary>=10000)
      return name;
    else
    return name+' less Sal';   
  }

}
