import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from './employee';

const headerConf = {
  headers : {'Content-type' : 'application/json'}
}

@Injectable({
  providedIn: 'root'
})
export class EmpService {


  uri:string='assets/employee.json';

  constructor(private httpClient : HttpClient) {


   }
 
 
 
   getEmpListByHttp():Observable<Employee[]>
   {
     return this.httpClient.get<Employee[]>(this.uri)
   }

   postEmp(emp:Employee) :Observable<Employee> {
    return this.httpClient.post<Employee>(this.uri, emp, headerConf);
  }

  putEmp(emp:Employee,id:number) :Observable<Employee> {
    return this.httpClient.put<Employee>(this.uri+'/'+id, emp, headerConf);
  }
  delEmp(id:number) : Observable<Employee> {
    return this.httpClient.delete<Employee>(this.uri+'/'+id, headerConf);
}

}
