import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comp1',
  templateUrl: './comp1.component.html',
  styleUrls: ['./comp1.component.css']
})
export class Comp1Component implements OnInit {
  a:number=1004545;
  name:string="Manjiri";

  isHidden:boolean=true;

  constructor() { }

  ngOnInit() {
  }

  myno():number{
    return Math.random();
  }

  hello():void {
    alert("Welcome to Bank");
  }
}
