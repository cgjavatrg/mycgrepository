import { Component, OnInit } from '@angular/core';
import { UrlService } from '../url.service';

@Component({
  selector: 'app-urlservice',
  templateUrl: './urlservice.component.html',
  styleUrls: ['./urlservice.component.css']
})
export class UrlserviceComponent implements OnInit {

  public persondata:any= [];
  constructor(private service:UrlService) { }

  ngOnInit() {
    this.service.getData().subscribe((data) => {
      this.persondata = data;
      console.log(JSON.stringify (this.persondata));
   });
  }
}
