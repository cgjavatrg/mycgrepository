import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UrlserviceComponent } from './urlservice.component';

describe('UrlserviceComponent', () => {
  let component: UrlserviceComponent;
  let fixture: ComponentFixture<UrlserviceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UrlserviceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UrlserviceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
