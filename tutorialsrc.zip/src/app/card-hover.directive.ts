import { Directive, ElementRef, HostBinding, HostListener, Renderer } from '@angular/core';

@Directive({
  selector: '[appCardHover]'
})
export class CardHoverDirective {
  @HostBinding('style.color') private mycolor: string; 

	constructor(private el: ElementRef, private renderer: Renderer) { 
    renderer.setElementStyle(el.nativeElement, 'backgroundColor', 'lightyellow');   
}

@HostListener('mouseover') onHover() {  
	//window.alert("hover");
  let part = this.el.nativeElement.querySelector('.card-text')     
  	this.renderer.setElementStyle(part, 'display', 'block');   
    this.mycolor = "green";

}  
@HostListener('mouseleave') onLeave() {  
	//window.alert("hover");
  let part = this.el.nativeElement.querySelector('.card-text')     
  	this.renderer.setElementStyle(part, 'display', 'none');   
    this.mycolor = "blue";

}  


}
