import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './user';
import { UserDTO } from './user-dto';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private baseUrl:string = 'http://localhost:8082/';  
  
  constructor(private http:HttpClient) { }  

  loginfun(username:string,password:string):Observable<UserDTO> {
    let params = new HttpParams()
    .set('username', username)
    .set('password', password)
    let url:string=`${this.baseUrl}accounts/login`;
     return this.http.post<UserDTO>(url,params   );
  }

  createUser(regUser:User):Observable<UserDTO> {
    let url:string=`${this.baseUrl}accounts/createUser`;
    return this.http.post<UserDTO>(url,regUser);
  }

}
