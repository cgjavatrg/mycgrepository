import { Component, OnInit } from '@angular/core';
import {AccountDetailsComponent } from '../account-details/account-details.component';
import { Observable } from "rxjs";
import {AccountServiceService} from '../account-service.service';
import { Account } from '../account';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-accounts',
  templateUrl: './list-accounts.component.html',
  styleUrls: ['./list-accounts.component.css']
})
export class ListAccountsComponent implements OnInit {
  accounts: Observable<Account[]>;

  constructor(private accountservice:AccountServiceService,
     private router:Router) { }

  ngOnInit(): void {
    this.reloadData();
  }

  reloadData() {
    this.accounts = this.accountservice.getAccountsList();
  }

  deleteAccount(id: number) {
    this.accountservice.deleteAccount(id)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

  accountDetails(id: number){
    this.router.navigate(['account-details', id]);
  }

  goForUpdate(id: number){
    this.router.navigate(['update-account', id]);
  }
}
