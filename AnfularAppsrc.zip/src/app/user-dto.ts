import { Role } from "./role.enum";

export class UserDTO {
    username:string;
    role:Role;
    createdAt:Date;
}
