import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpHandler, HttpRequest, HttpEvent, HttpResponse }
  from '@angular/common/http';

//import { Observable } from 'rxjs/Observable';
import { Observable } from 'rxjs';
//import 'rxjs/add/operator/do';
import {tap, map} from 'rxjs/operators';

@Injectable()
export class MyInterceptor implements HttpInterceptor {
  /*intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    return next.handle(req).pipe(
        tap(evt => {
            console.log(evt);
            if (evt instanceof HttpResponse) {
              console.log('---&gt; status:', evt.status);
              console.log('---&gt; filter:', req.params.get('filter'));
              }
              return evt;
           })
    );
    /*.tap(evt => {
        if (evt instanceof HttpResponse) {
          console.log('---&gt; status:', evt.status);
          console.log('---&gt; filter:', req.params.get('filter'));
          }
          return evt;
          });
      */    
  //}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    console.log(request);
   /* const token: string = localStorage.getItem('token');

    if (token) {
        request = request.clone({ headers: request.headers.set('Authorization', 'Bearer ' + token) });
    }

    if (!request.headers.has('Content-Type')) {
        request = request.clone({ headers: request.headers.set('Content-Type', 'application/json') });
    }

    request = request.clone({ headers: request.headers.set('Accept', 'application/json') });
      */
    return next.handle(request).pipe(
        map((event: HttpEvent<any>) => {
            console.log(JSON.stringify(event));
            if (event instanceof HttpResponse) {
                console.log('event--->>>', event);
            }
            return event;
        }));

}
  
}