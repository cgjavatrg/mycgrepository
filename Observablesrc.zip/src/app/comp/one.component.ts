import { Component, OnInit } from '@angular/core';
import { of, interval, range, throwError, timer, iif, from } from 'rxjs';
import { map, reduce, filter,retry, take, count, max, min, concat, expand, groupBy, mergeMap, catchError } from 'rxjs/operators';
import { ajax } from 'rxjs/ajax';
@Component({
  selector: 'app-one',
  templateUrl: './one.component.html',
  styleUrls: ['./one.component.css']
})
export class OneComponent implements OnInit {
  sumData:any;
  ajaxResponse:any;
  intervalData:any;
  rangeData:any;
  timerData:any;
  ifData:any;
  count:any;
  maxNo;
  minNo;
  sumData1;
  concatData: number;
  arrdata: number;
  groupData: any;
  groupwiseData: any[];
  grdata: { id: string | { groupId: string; value: number; }; values: (string | { groupId: string; value: number; })[]; };
  constructor() { }

  ngOnInit(): void {
    this.methodSum();
    this.methodForInterval();
    this.methodForRange();
    //this.methodForTimer();
    this.methodForIf();
    this.methodForMathsOperators();
    this.methodForJoinOperators();
    this.methodForTransformationOperators();
    //this.methodForThrowError();
    this.methodForAjax();
  }

  methodSum() {
    let test1 = of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
    let case1 = test1.pipe(
      filter(x => x % 2 === 0),
      reduce((acc, one) => acc + one, 0)
    )
    case1.subscribe(x =>this.sumData=x);
    case1.subscribe(x => console.log(x));
  }

  methodForAjax(){
    /*
    let final_val = ajax('https://jsonplaceholder.typicode.com/users').pipe(
      map(e => e.response)
    );
    */
    let final_val = ajax('https://jsonplaceholder.typicode.com/users').pipe(
      map(e => {
        if(!e.response) {
          throw new Error ("Value Expected from response");
        }
        return  e.response;
      }),
      catchError(err=> of ([]))
      );
    //final_val.subscribe(x => console.log(x));
    final_val.subscribe({
      next(x){console.log("data :"+JSON.stringify(x))} ,
      error(err){console.log("Error already caught "+err)}
    });
    final_val.subscribe(x => this.ajaxResponse=x);

  }

  methodForInterval(){
    let test = interval(2000);
    let case1 = test.pipe(take(5));
    case1.subscribe(x => console.log(x));
    case1.subscribe(x => this.intervalData=x);
  }

  methodForRange() {
    let ints = range(1, 10);
    ints.subscribe(x => console.log(x));
    ints.subscribe(x => this.rangeData=x);
  }

  /*
  methodForThrowError() {
    const result =throwError(new Error('MY error occurred'));
    result.subscribe(x => console.log(x), e => console.error(e));
  }
  */

  methodForTimer() {
    let all_numbers = timer(10000, 10);
    all_numbers.subscribe(x => console.log(x));
    all_numbers.subscribe(x => this.timerData=x);
  }

  methodForIf() {
    let task1 = iif(
      () => (Math.random() + 1) % 2 === 0,
      of("Even Case"),
      of("Odd Case")
   );
   task1.subscribe(value => console.log(value));
   task1.subscribe(value => this.ifData=value);
  }

  methodForMathsOperators(){
    
    let all_nums = of(1, 7, 5, 10, 10, 20);
    let final_val = all_nums.pipe(count());
    final_val.subscribe(x => console.log("The count is "+x));
    final_val.subscribe(x => this.count=x);

    final_val = all_nums.pipe(max());
    final_val.subscribe(x => console.log("The Max value is "+x));
    final_val.subscribe(x => this.maxNo=x);

    final_val = all_nums.pipe(min());
    final_val.subscribe(x => console.log("The Max value is "+x));
    final_val.subscribe(x => this.minNo=x);

    let items = [
      {item1: "A", price: 1000.00},
      {item2: "B", price: 850.00},
      {item2: "C", price: 200.00},
      {item2: "D", price: 150.00}
   ];
   final_val = from(items).pipe(reduce((acc, itemsdet) => acc+itemsdet.price, 0));
   final_val.subscribe(x => console.log("Total Price is: "+x));
   final_val.subscribe(x =>this.sumData1=x);
   
  }

  methodForJoinOperators() {
    let list1 = of(2, 3, 4, 5, 6);
    let list2 = of(4, 9, 16, 25, 36)
    let final_val = list1.pipe(concat(list2));
    final_val.subscribe(x => console.log(x));
    final_val.subscribe(x => this.concatData=x);
  }

  methodForTransformationOperators(){
  /*
    let buffered_array = of(2).pipe(expand(x => of(2 * x)));
    buffered_array.subscribe(arr => console.log(arr));
    buffered_array.subscribe(arr => this.arrdata=arr);
    */
  const nums=of(1,2,3,4);
  const squareValues=map((x:number) => x*x);
  const squareNums=squareValues(nums);
  squareNums.subscribe(x => console.log(x));



   const data = [
      {groupId: "QA", value: 1},
      {groupId: "Development", value: 3},
      {groupId: "QA", value: 5},
      {groupId: "Development", value: 6},
      {groupId: "QA", value: 2},
    ];
 
    let mydata=from(data).pipe(
        groupBy(item => item.groupId),

    )
    mydata.subscribe(x => console.log(x));
    mydata.subscribe(x => this.groupData=x);

    let mydata1=from(data).pipe(
        groupBy(item => item.groupId),
        mergeMap((group$) => group$.pipe(reduce((acc, cur) => [...acc, cur], []))),
      );

      mydata1.subscribe(x => console.log(x));
      mydata1.subscribe(x => this.groupwiseData=x);
 
      let mydata2=from(data).pipe(
        groupBy(item => item.groupId),
        mergeMap(group$ =>
            group$.pipe(reduce((acc, cur) => [...acc, cur], [`${group$.key}`]))
          ),
          map(arr => ({ id: arr[0], values: arr.slice(1) }))
        );
    
        mydata2.subscribe(p => console.log(p));
        mydata2.subscribe(p => this.grdata=p);


  }


}
